Place your renamed photos in this folder.

Required filenames:
- graduation.jpg
- headshot.jpg
- hawaii.jpg
- dive.jpg
- bump.jpg
- hoodie_front.jpg
- hoodie_back.jpg
- usc_logo.jpg

See DEPLOYMENT_GUIDE.md for the full rename table.
