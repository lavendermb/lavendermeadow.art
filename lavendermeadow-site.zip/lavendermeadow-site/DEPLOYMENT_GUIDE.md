# 🌸 Lavender Meadow — Deployment Guide
## lavendermeadow.art on Cloudflare Pages

---

## FOLDER STRUCTURE

Your site folder should look exactly like this before uploading:

```
lavendermeadow-site/
├── index.html          ← The main website file
├── _headers            ← Cloudflare caching & security rules
├── _redirects          ← Cloudflare redirect rules
└── images/
    ├── graduation.jpg
    ├── headshot.jpg
    ├── hawaii.jpg
    ├── dive.jpg
    ├── bump.jpg
    ├── hoodie_front.jpg
    ├── hoodie_back.jpg
    └── usc_logo.jpg
```

---

## STEP 1 — RENAME YOUR PHOTOS

Rename the photos you were given to match exactly:

| Your original file                          | Rename to          |
|---------------------------------------------|--------------------|
| Screen_Shot_2026-04-23_at_7_27_12_PM.png   | graduation.jpg     |
| Screen_Shot_2026-04-23_at_7_34_50_PM.png   | headshot.jpg       |
| Screen_Shot_2026-04-23_at_7_28_19_PM.png   | hawaii.jpg         |
| Screen_Shot_2026-04-23_at_7_27_58_PM.png   | dive.jpg           |
| Screen_Shot_2026-04-23_at_7_27_42_PM.png   | bump.jpg           |
| Screen_Shot_2026-04-23_at_7_35_07_PM.png   | hoodie_front.jpg   |
| Screen_Shot_2026-04-23_at_7_29_32_PM.png   | hoodie_back.jpg    |
| Screen_Shot_2026-04-23_at_7_28_54_PM.png   | usc_logo.jpg       |

(PNG files work fine renamed as .jpg — or keep as .png and update the
 src paths in index.html from .jpg → .png if you prefer)

Put all renamed photos inside the `images/` folder.

---

## STEP 2 — DEPLOY TO CLOUDFLARE PAGES

### Option A — Drag & Drop (Easiest, no account setup needed)

1. Go to: https://pages.cloudflare.com
2. Sign in or create a free Cloudflare account
3. Click **"Create a project"** → **"Direct Upload"**
4. Name your project: `lavendermeadow`
5. Drag the entire `lavendermeadow-site/` folder into the upload box
6. Click **"Deploy site"**
7. Cloudflare will give you a free URL like `lavendermeadow.pages.dev`

### Option B — GitHub (Best for ongoing edits)

1. Create a free GitHub account at github.com if you don't have one
2. Create a new repository called `lavendermeadow-site`
3. Upload all your files (keeping the folder structure above)
4. In Cloudflare Pages → "Create a project" → "Connect to Git"
5. Select your GitHub repo
6. Build settings: leave blank (static site, no build needed)
7. Click Deploy

Every time you push a change to GitHub, the site auto-updates. ✓

---

## STEP 3 — CONNECT YOUR DOMAIN (lavendermeadow.art)

1. In Cloudflare Pages, go to your project → **"Custom domains"**
2. Click **"Set up a custom domain"**
3. Enter: `lavendermeadow.art`
4. Cloudflare will walk you through DNS setup

**If your domain is already registered through Cloudflare:**
- It's automatic — just confirm and it connects in minutes.

**If your domain is at another registrar (GoDaddy, Namecheap, etc.):**
- Cloudflare will show you two nameservers (e.g. `ada.ns.cloudflare.com`)
- Log into your registrar and update the nameservers to Cloudflare's
- Takes 24–48 hours to fully propagate

---

## STEP 4 — AFTER LAUNCH CHECKLIST

- [ ] Visit lavendermeadow.art and check every section
- [ ] Test the EN/FR language toggle
- [ ] Fill out the contact form to make sure it feels right
  (Note: for the form to actually SEND emails, you'll need to add
   Formspree or Netlify Forms — see below)
- [ ] Click all gallery photos to confirm lightbox works
- [ ] Test on mobile

---

## OPTIONAL — MAKE THE CONTACT FORM ACTUALLY SEND EMAILS

The form currently shows a success message but doesn't email you.
To receive real project requests in your inbox:

### Using Formspree (free, 50 submissions/month):
1. Go to https://formspree.io and create a free account
2. Create a new form → copy your form ID (looks like `xabcdefg`)
3. In index.html, find `<div class="request-form reveal">` and the
   button with id="submitBtn"
4. Replace the `onclick="submitForm()"` button with a proper form:
   - Wrap the inputs in `<form action="https://formspree.io/f/YOUR_ID" method="POST">`
   - Change the button to `type="submit"`
5. Done — submissions go straight to lavendrmb@gmail.com

### Using Stripe for payments:
1. Create a Stripe account at stripe.com
2. Create Payment Links in your Stripe dashboard for each service tier
3. Update the service cards or form submit button to link to your
   Stripe payment pages
4. Stripe handles all card processing securely — you just get paid

---

## MAKING FUTURE EDITS

The site is a single HTML file (`index.html`). To edit:
- Open it in any text editor (TextEdit on Mac, Notepad on Windows,
  or VS Code for a better experience — free at code.visualstudio.com)
- Change any text between the quotes in `data-en="..."` attributes
- Save and re-upload to Cloudflare Pages (drag & drop again)
- The site updates in ~30 seconds

To ADD photos to the gallery, find the `collage-strip` section in
index.html and add new `<div class="col-cell">` blocks with your image.

---

## SUPPORT

Questions? Email: lavendrmb@gmail.com
Domain: lavendermeadow.art
Instagram: @lavendermeadowb

🌿 Every project plants a seed.
